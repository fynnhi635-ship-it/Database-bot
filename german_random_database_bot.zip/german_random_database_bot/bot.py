import os
import random
import sqlite3
from typing import Optional

import discord
from discord import app_commands
from discord.ext import commands
import requests
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
DB_PATH = os.getenv("DB_PATH", "german_places.sqlite3")

# Public OpenStreetMap data. Please use responsibly and retain attribution.
OVERPASS_URL = "https://overpass-api.de/api/interpreter"
HEADERS = {"User-Agent": "GermanRandomDatabaseBot/1.0 (Discord bot; educational project)"}

GERMAN_CITIES = [
    ("Berlin", 52.5200, 13.4050), ("Hamburg", 53.5511, 9.9937),
    ("Munich", 48.1372, 11.5756), ("Cologne", 50.9375, 6.9603),
    ("Frankfurt am Main", 50.1109, 8.6821), ("Leipzig", 51.3397, 12.3731),
    ("Dresden", 51.0504, 13.7373), ("Stuttgart", 48.7758, 9.1829),
    ("Dortmund", 51.5136, 7.4653), ("Hannover", 52.3759, 9.7320),
    ("Nuremberg", 49.4521, 11.0767), ("Bremen", 53.0793, 8.8017),
    ("Essen", 51.4556, 7.0116), ("Duisburg", 51.4344, 6.7623),
    ("Augsburg", 48.3705, 10.8978), ("Potsdam", 52.3906, 13.0645),
]

def connect():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("""
        CREATE TABLE IF NOT EXISTS places (
            osm_type TEXT NOT NULL,
            osm_id TEXT NOT NULL,
            name TEXT NOT NULL,
            category TEXT,
            street TEXT,
            house_number TEXT,
            postcode TEXT,
            city TEXT,
            website TEXT,
            phone TEXT,
            lat REAL,
            lon REAL,
            PRIMARY KEY (osm_type, osm_id)
        )
    """)
    con.commit()
    return con

def overpass_fetch(city: str, lat: float, lon: float):
    # Only public place/business POIs; no private-person records.
    query = f"""
    [out:json][timeout:25];
    (
      node(around:5000,{lat},{lon})[name][~"^(amenity|shop|tourism|leisure|office)$"~"."]; 
      way(around:5000,{lat},{lon})[name][~"^(amenity|shop|tourism|leisure|office)$"~"."]; 
    );
    out center tags;
    """
    response = requests.post(OVERPASS_URL, data=query, headers=HEADERS, timeout=35)
    response.raise_for_status()
    elements = response.json().get("elements", [])
    saved = 0
    con = connect()
    try:
        for el in elements:
            tags = el.get("tags", {})
            name = tags.get("name")
            if not name:
                continue
            lat_v = el.get("lat") or el.get("center", {}).get("lat")
            lon_v = el.get("lon") or el.get("center", {}).get("lon")
            if lat_v is None or lon_v is None:
                continue
            street = tags.get("addr:street")
            house = tags.get("addr:housenumber")
            postcode = tags.get("addr:postcode")
            place_city = tags.get("addr:city") or city
            category = next((tags[k] for k in ("amenity", "shop", "tourism", "leisure", "office") if k in tags), "POI")
            con.execute("""
                INSERT OR REPLACE INTO places
                (osm_type, osm_id, name, category, street, house_number, postcode, city, website, phone, lat, lon)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                el.get("type", "node"), str(el.get("id")), name, category,
                street, house, postcode, place_city, tags.get("website"),
                tags.get("phone"), float(lat_v), float(lon_v)
            ))
            saved += 1
        con.commit()
    finally:
        con.close()
    return saved

def random_city():
    return random.choice(GERMAN_CITIES)

def get_random_place():
    con = connect()
    try:
        row = con.execute("SELECT * FROM places ORDER BY RANDOM() LIMIT 1").fetchone()
    finally:
        con.close()
    if row:
        return dict(row)
    city, lat, lon = random_city()
    overpass_fetch(city, lat, lon)
    con = connect()
    try:
        row = con.execute("SELECT * FROM places ORDER BY RANDOM() LIMIT 1").fetchone()
        return dict(row) if row else None
    finally:
        con.close()

def search_places(term: str, city: Optional[str] = None):
    con = connect()
    try:
        pattern = f"%{term}%"
        if city:
            rows = con.execute("""
                SELECT * FROM places
                WHERE (name LIKE ? OR category LIKE ?) AND city LIKE ?
                ORDER BY name LIMIT 8
            """, (pattern, pattern, f"%{city}%")).fetchall()
        else:
            rows = con.execute("""
                SELECT * FROM places
                WHERE name LIKE ? OR category LIKE ?
                ORDER BY name LIMIT 8
            """, (pattern, pattern)).fetchall()
        return [dict(r) for r in rows]
    finally:
        con.close()

def place_embed(p, title="Zufälliger öffentlicher Datensatz"):
    e = discord.Embed(title=title, color=discord.Color.blurple())
    e.add_field(name="Name", value=p.get("name") or "Unbekannt", inline=False)
    e.add_field(name="Kategorie", value=p.get("category") or "POI", inline=True)
    e.add_field(name="Ort", value=p.get("city") or "Unbekannt", inline=True)
    address = " ".join(x for x in [p.get("street"), p.get("house_number")] if x)
    if p.get("postcode"):
        address = f"{p['postcode']} {address}".strip()
    e.add_field(name="Öffentliche Adresse", value=address or "Nicht in OSM hinterlegt", inline=False)
    if p.get("phone"):
        e.add_field(name="Öffentliche Telefonnummer", value=p["phone"], inline=True)
    if p.get("website"):
        e.add_field(name="Website", value=p["website"], inline=True)
    if p.get("lat") is not None and p.get("lon") is not None:
        e.add_field(name="Koordinaten", value=f"{p['lat']:.6f}, {p['lon']:.6f}", inline=False)
        e.add_field(name="OpenStreetMap", value=f"https://www.openstreetmap.org/{p['osm_type']}/{p['osm_id']}", inline=False)
    e.set_footer(text="Quelle: OpenStreetMap-Mitwirkende • Nur öffentliche Orts-/Geschäftsdaten")
    return e

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    try:
        synced = await bot.tree.sync()
        print(f"Angemeldet als {bot.user}; {len(synced)} Slash-Befehle synchronisiert.")
    except Exception as exc:
        print(f"Slash-Befehle konnten nicht synchronisiert werden: {exc}")

@bot.tree.command(name="random", description="Zeigt einen zufälligen öffentlichen Ort oder Betrieb aus Deutschland.")
async def random_command(interaction: discord.Interaction):
    await interaction.response.defer(thinking=True)
    try:
        p = get_random_place()
        if p:
            await interaction.followup.send(embed=place_embed(p))
        else:
            await interaction.followup.send("Keine Daten gefunden. Bitte später erneut versuchen.")
    except requests.RequestException:
        await interaction.followup.send("Die öffentliche OpenStreetMap-Datenquelle ist gerade nicht erreichbar. Bitte später erneut versuchen.")
    except Exception:
        await interaction.followup.send("Beim Abrufen ist ein Fehler aufgetreten.")

@bot.tree.command(name="search", description="Sucht gespeicherte öffentliche Orte und Betriebe.")
@app_commands.describe(begriff="Name oder Kategorie", stadt="Optional: Stadt")
async def search_command(interaction: discord.Interaction, begriff: str, stadt: Optional[str] = None):
    rows = search_places(begriff, stadt)
    if not rows:
        await interaction.response.send_message(
            "Nichts in der lokalen Datenbank gefunden. Nutze zuerst /random, um öffentliche Daten zu laden.",
            ephemeral=True
        )
        return
    embeds = [place_embed(p, title=f"Suchtreffer {i+1}") for i, p in enumerate(rows[:5])]
    await interaction.response.send_message(embeds=embeds)

@bot.tree.command(name="randomlocation", description="Lädt zufällige öffentliche Orte aus einer deutschen Stadt.")
@app_commands.describe(stadt="Stadtname, z. B. Leipzig")
async def randomlocation_command(interaction: discord.Interaction, stadt: str):
    match = next((c for c in GERMAN_CITIES if c[0].lower() == stadt.lower()), None)
    if not match:
        await interaction.response.send_message(
            "Diese Stadt ist noch nicht in der eingebauten Städteliste. Verfügbar: " +
            ", ".join(c[0] for c in GERMAN_CITIES), ephemeral=True
        )
        return
    await interaction.response.defer(thinking=True)
    try:
        count = overpass_fetch(*match)
        con = connect()
        try:
            row = con.execute("SELECT * FROM places WHERE city LIKE ? ORDER BY RANDOM() LIMIT 1", (f"%{match[0]}%",)).fetchone()
            p = dict(row) if row else None
        finally:
            con.close()
        if p:
            await interaction.followup.send(embed=place_embed(p, title=f"Zufälliger Datensatz aus {match[0]}"))
        else:
            await interaction.followup.send(f"Keine passenden öffentlichen Daten gefunden (neue Einträge: {count}).")
    except requests.RequestException:
        await interaction.followup.send("OpenStreetMap ist gerade nicht erreichbar. Bitte später erneut versuchen.")

@bot.tree.command(name="database", description="Zeigt die Größe deiner lokalen Datenbank.")
async def database_command(interaction: discord.Interaction):
    con = connect()
    try:
        count = con.execute("SELECT COUNT(*) FROM places").fetchone()[0]
        cities = con.execute("SELECT COUNT(DISTINCT city) FROM places").fetchone()[0]
    finally:
        con.close()
    await interaction.response.send_message(
        f"**German Public Places Database**\nDatensätze: **{count}**\nOrte/Städte: **{cities}**\nQuelle: OpenStreetMap"
    )

@bot.tree.command(name="help", description="Zeigt die Bot-Befehle.")
async def help_command(interaction: discord.Interaction):
    await interaction.response.send_message(
        "**Befehle**\n"
        "`/random` – zufälliger öffentlicher Ort/Betrieb\n"
        "`/randomlocation stadt:<Name>` – Daten aus einer unterstützten Stadt laden\n"
        "`/search begriff:<Text> [stadt:<Stadt>]` – lokale Datenbank durchsuchen\n"
        "`/database` – Datenbankstatistik\n\n"
        "Es werden ausschließlich öffentliche Orts- und Unternehmensdaten genutzt, keine privaten Personendaten."
    )

if not TOKEN:
    raise RuntimeError("DISCORD_TOKEN fehlt. Lege eine .env-Datei anhand von .env.example an.")
bot.run(TOKEN)
