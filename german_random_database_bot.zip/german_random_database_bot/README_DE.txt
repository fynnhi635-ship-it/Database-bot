GERMAN RANDOM DATABASE BOT – EINRICHTUNG

Was der Bot macht
- /random: zufälliger öffentlicher Ort/Betrieb aus Deutschland
- /randomlocation stadt:<Name>: lädt öffentliche POIs aus einer unterstützten Stadt
- /search begriff:<Text> [stadt:<Stadt>]: durchsucht bereits geladene Datensätze
- /database: zeigt die Anzahl gespeicherter Datensätze
- /help: zeigt die Befehle

WICHTIG
Dieser Bot sammelt öffentliche Orts- und Unternehmensdaten aus OpenStreetMap.
Er sammelt KEINE privaten Personendaten, Wohnadressen von Privatpersonen,
persönlichen Telefonnummern oder personenbezogene IP-Adressen.
Telefonnummern/Websites erscheinen nur, wenn sie öffentlich in OpenStreetMap
hinterlegt sind. Die Datenbank wird nach und nach durch die Nutzung gefüllt.

VORAUSSETZUNGEN
- Python 3.10 oder neuer
- Ein Discord-Bot im Discord Developer Portal
- Internetverbindung

1. BOT ERSTELLEN
1) Öffne https://discord.com/developers/applications
2) New Application -> Namen vergeben.
3) Unter Bot -> Add Bot.
4) Reset Token / Copy Token. Den Token NIEMALS jemandem schicken oder veröffentlichen.
5) Unter OAuth2 -> URL Generator:
   - Scopes: bot, applications.commands
   - Bot Permissions: Send Messages, Embed Links, Read Message History
6) Öffne den erzeugten Link und füge den Bot deinem Server hinzu.

2. DATEIEN EINRICHTEN
1) Entpacke das ZIP.
2) Benenne .env.example in .env um.
3) Öffne .env und trage deinen Bot-Token ein.
4) Speichere die Datei. Teile den Token mit niemandem.

3. STARTEN
Windows:
  py -m venv .venv
  .venv\Scripts\activate
  pip install -r requirements.txt
  py bot.py

macOS/Linux:
  python3 -m venv .venv
  source .venv/bin/activate
  pip install -r requirements.txt
  python bot.py

Wenn im Terminal "Angemeldet als ..." steht, ist der Bot online.
Die Slash-Befehle können nach dem ersten Start kurz brauchen, bis Discord sie zeigt.

DAUERBETRIEB
Der Bot läuft nur, solange das Gerät/der Server und das Programm laufen.
Für 24/7-Betrieb brauchst du einen dauerhaft laufenden Hosting-Dienst.
Lade niemals die .env-Datei oder den Token in GitHub hoch.

DATENQUELLE / LIZENZ
Datenquelle: OpenStreetMap (https://www.openstreetmap.org)
Die Daten stehen unter der Open Database License (ODbL).
Attribution: © OpenStreetMap contributors.
Overpass API: https://overpass-api.de/
Bitte die öffentliche API fair nutzen; bei hoher Nutzung einen eigenen Overpass-Server
oder einen geeigneten Datenanbieter verwenden.
